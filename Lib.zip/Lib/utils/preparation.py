import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, PowerTransformer, QuantileTransformer

'''置換'''
def imputation_of_missing_values(x_train, x_test):
    '''欠損データを数値データに置き換える'''
    imp = SimpleImputer(missing_values=-1,strategy='most_frequent') # strategy:'mean','median','most_frequent'or'constant'
    imp.fit(x_train)
    x_train = imp.transform(x_train)
    x_test = imp.transform(x_test)
    return x_train, x_test

def clipping(x_train, x_test):
    '''1%点を下限,99%点を上限にしてclipping'''
    p01 = np.quantile(x_train,0.01,axis=0)
    p99 = np.quantile(x_train,0.99,axis=0)
    x_train = x_train.clip(p01,p99)
    x_test = x_test.clip(p01,p99)
    return x_train, x_test

'''変換'''
def standardize(x_train, x_test):
    '''平均0,分散1に標準化'''
    sc = StandardScaler()
    sc.fit(x_train)
    x_train = sc.transform(x_train)
    x_test = sc.transform(x_test)
    return x_train,x_test

def normalize(x_train, x_test):
    '''最小値0,最大値1に正規化'''
    sc = MinMaxScaler()
    sc.fit(x_train)
    x_train = sc.transform(x_train)
    x_test = sc.transform(x_test)
    return x_train,x_test

def box_cox(x_train, x_test):
    '''BoxCox変換'''
    pt = PowerTransformer(method='box-cox') #'box-cox' or 'yeo-johnson'
    pt.fit(x_train)
    x_train = pt.transform(x_train)
    x_test = pt.transform(x_test)
    return x_train,x_test

def RankGauss(x_train, x_test):
    '''RankGauss変換'''
    qt = QuantileTransformer(n_quantiles=len(x_train),output_distribution='normal')
    qt.fit(x_train)
    x_train = qt.transform(x_train)
    x_test = qt.transform(x_test)
    return x_train,x_test

def log(data):
    '''対数変換'''
    return np.sign(data) * np.log(np.abs(data) + 1)