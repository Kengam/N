import MachineLearning.BinaryClassification.main
def main():
    MachineLearning.BinaryClassification.main.main()

if __name__ == '__main__':
    main()