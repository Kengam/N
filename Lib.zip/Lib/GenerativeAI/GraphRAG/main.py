def main():
    print('OK')

if __name__ == '__main__':
    main()